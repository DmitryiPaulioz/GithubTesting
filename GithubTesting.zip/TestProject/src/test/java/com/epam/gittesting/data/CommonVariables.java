package com.epam.gittesting.data;

public interface CommonVariables {
    String username = "DmitryiPaulioz";
    String password = "m9z7dMark3speed";


    String exePath = "C:\\Users\\dmitryi_paulioz\\Desktop\\Librarys\\geckodriver.exe";
    String geckodriver = "webdriver.gecko.driver";

    String loginPageURL = "https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fsettings%2Fprofile";
    String profileURL = "https://github.com/settings/profile";
    String newRepoURL = "https://github.com/new";
}
