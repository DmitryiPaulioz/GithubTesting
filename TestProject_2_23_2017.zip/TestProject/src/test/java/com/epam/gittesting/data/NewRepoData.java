package com.epam.gittesting.data;

public class NewRepoData {
    private String repoName;

    public NewRepoData(){
        repoName = "NewTestRepo";
    }

    public String getRepoName() {
        return repoName;
    }
}
