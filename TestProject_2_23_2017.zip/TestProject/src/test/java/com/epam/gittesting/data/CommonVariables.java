package com.epam.gittesting.data;

public interface CommonVariables {
    String username = "DmitryiPaulioz";
    String password = "m9z7dMark3speed";

    String exePath = "C:\\selenium\\geckodriver.exe";
    String geckodriver = "webdriver.gecko.driver";

    String loginPageURL = "https://github.com/login";
    String profileURL = "https://github.com/settings/profile";
    String newRepoURL = "https://github.com/new";
}
